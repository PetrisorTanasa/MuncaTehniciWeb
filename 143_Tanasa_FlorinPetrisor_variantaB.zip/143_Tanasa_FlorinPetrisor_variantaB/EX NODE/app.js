const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

const express = require('express')
const app = express()
const path = require('path');
const res = require('express/lib/response');

app.set('views',path.join(__dirname,'/views'));
app.use(express.static(path.join(__dirname,'/static')))
app.set('view engine','ejs')
app.use(express.urlencoded({extended:false}));
app.use(express.json());

app.get('/',(req,res)=>{
  res.sendFile(path.join(__dirname,'home.html'))
})

app.post('/',(req,res)=>{

console.log(req.body.numere)

nr = req.body.numere.split(',')

for(let i of nr){
  if(parseInt(i) != i){res.send("imposibil")}
}

nr.sort()
console.log(nr)

for(let i=0;i<nr.length-1;i++){
  if(nr[i+1] - nr[i] != 1){res.send("Nu este o permutare a lui N")}
}

res.send("Este o permutare a lui N")

})

app.listen(3000,()=>{
  console.log('App is listening at Port 3000.')
})