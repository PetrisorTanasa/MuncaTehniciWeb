let lista = [];

function Creatie(){
    fetch("http://127.0.0.1:3000/update")
    .then((res)=>res.json())
    .then(function(res){
        console.log(res)
    })
}